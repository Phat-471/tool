using System.Reflection;

internal delegate FieldInfo[] GetDelegateFieldinfo_1(object P_0, BindingFlags P_1);

internal delegate void GetDelegateVoid_1(object P_0, object[] P_1);

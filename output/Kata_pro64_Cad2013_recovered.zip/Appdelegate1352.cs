using Autodesk.AutoCAD.DatabaseServices;

internal delegate BlockTableRecordEnumerator GetDelegateBlocktablerecordenumerator_1(object P_0);

internal delegate int GetDelegateInt_1(object P_0, char P_1, int P_2, int P_3);

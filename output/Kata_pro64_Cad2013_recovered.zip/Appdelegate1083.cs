using Kata_Class_Lib_Revit;

internal delegate diem GetDelegateDiem_1(ref diem P_0, ref diem P_1);

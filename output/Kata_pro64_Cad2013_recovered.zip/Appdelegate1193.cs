using System.Windows.Forms;

internal delegate void GetDelegateVoid_1(object P_0, AutoScaleMode P_1);

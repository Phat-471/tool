using System.Windows.Forms;

internal delegate DataGridViewColumnCollection GetDelegateDatagridviewcolumncollection_1(object P_0);
